package com.aurora.roleplay

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val SERVER_IP = "188.165.192.24:5644" // embedded server IP

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // show splash image
        val splash: ImageView = findViewById(R.id.splashImage)
        splash.setImageResource(R.drawable.splash_image)

        // show server ip and save to SharedPreferences (data própria)
        val tv: TextView = findViewById(R.id.serverIp)
        val prefs = getSharedPreferences("aurora_prefs", Context.MODE_PRIVATE)
        val stored = prefs.getString("server_ip", SERVER_IP) ?: SERVER_IP
        tv.text = "Servidor: $stored"

        // save by default if not present
        if (!prefs.contains("server_ip")) {
            prefs.edit().putString("server_ip", SERVER_IP).apply()
        }

        val btnConnect: Button = findViewById(R.id.btnConnect)
        btnConnect.setOnClickListener {
            // attempt to open link (user can handle as they wish)
            val url = "samp://${SERVER_IP}" // custom scheme - many devices won't handle this; it's a placeholder
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                startActivity(intent)
            } catch (e: Exception) {
                AlertDialog.Builder(this)
                    .setTitle("Conectar")
                    .setMessage("Tente conectar manualmente pelo IP:\n$SERVER_IP")
                    .setPositiveButton("OK", null)
                    .show()
            }
        }
    }
    // SERVER_IP_PLACEHOLDER - injected by assistant
    private fun loadServerIp(): String? {
        return try {
            val `is` = assets.open("server_ip.txt")
            `is`.bufferedReader().use { it.readText().trim() }
        } catch (e: Exception) {
            null
        }
    }

}