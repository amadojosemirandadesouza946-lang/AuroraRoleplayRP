# BUILD_INSTRUCTIONS.md

## Objetivo
Gerar o APK do app **AURORA ROLEPLAY** contendo o IP do servidor.

## 1) Substituir o IP
Edite `server_ip.txt` e substitua o conteúdo pelo IP do seu servidor, por exemplo:
```
188.165.192.24:5644
```

## 2) Se o seu projeto é Android nativo (Android Studio)
- Abra o Android Studio.
- Importe a pasta do projeto (a raiz onde existem `app/`, `build.gradle`, etc).
- No código-fonte, localize onde o IP do servidor é referenciado (procure por `SEU_IP_AQUI` ou por `server_ip.txt`).
- Substitua e rode `Build > Build Bundle(s) / APK(s) > Build APK(s)`.

## 3) Se o projeto for Cordova / Ionic / PhoneGap
- Instale Node.js, npm e Cordova/Android SDK.
- Coloque o conteúdo do projeto Cordova na pasta `cordova_project/`.
- Edite `www/js/config.js` ou arquivo equivalente para usar o IP de `server_ip.txt`.
- Rode:
  ```
  cordova platform add android
  cordova build android --release
  ```
- Assine o APK com sua keystore:
  ```
  jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 -keystore my-release-key.keystore app-release-unsigned.apk alias_name
  zipalign -v 4 app-release-unsigned.apk aurora_roleplay_signed.apk
  ```

## 4) GitHub Actions (opcional)
Você pode configurar um workflow para compilar o APK automaticamente. Verifique `.github/workflows/build.yml` se presente e ajuste variáveis/secretos (KEYSTORE, ALIAS, PASSWORD).

## 5) Teste
Instale o APK no seu celular e verifique o nome `AURORA ROLEPLAY` e se o IP do servidor funciona ao abrir o app.

## Observações importantes
- Para publicar no Google Play você precisa assinar com keystore próprio.
- Se quiser que eu gere o APK (debug) e retorne aqui, me envie o IP e confirme que aceita um APK em modo debug (não para publicação) ou envie a keystore para assinar.
