# Aurora Roleplay — GitHub-ready project

Este repositório foi gerado automaticamente a partir do arquivo `aurora_roleplay_github_ready.zip` que você enviou.

**O que contém**
- Os arquivos que estavam no ZIP original (veja a lista abaixo).
- `server_ip.txt` — arquivo com o placeholder do IP do servidor (substitua pelo seu IP).
- `README.md` — este arquivo com instruções.
- `BUILD_INSTRUCTIONS.md` — instruções passo-a-passo para gerar o APK localmente ou via GitHub.

**Lista de arquivos extraídos**
```
AuroraRoleplay/build.gradle
AuroraRoleplay/settings.gradle
AuroraRoleplay/README.txt
AuroraRoleplay/app/build.gradle
AuroraRoleplay/app/proguard-rules.pro
AuroraRoleplay/app/src/main/AndroidManifest.xml
AuroraRoleplay/app/src/main/java/com/aurora/roleplay/MainActivity.kt
AuroraRoleplay/app/src/main/res/layout/activity_main.xml
AuroraRoleplay/app/src/main/res/drawable/splash_image.png
AuroraRoleplay/app/src/main/res/values/strings.xml
AuroraRoleplay/.github/workflows/build.yml
```

**Passos rápidos**
1. Substitua o conteúdo de `server_ip.txt` pelo IP do seu servidor (ex.: `188.165.192.24:5644`).
2. Se este projeto for um app Android (Cordova/PhoneGap/Flutter/React Native), coloque o projeto Android na pasta `android/` ou adapte as instruções em `BUILD_INSTRUCTIONS.md`.
3. Faça commit no GitHub. Se quiser, eu já deixei um esqueleto de workflow do GitHub Actions em `/.github/workflows/build.yml` (se aplicável) — você pode editar conforme seu projeto.

Se quiser que eu já substitua o placeholder do IP e gere um APK pronto, me envie o IP agora e (se tiver) sua **keystore** para assinar o APK ou indique se quer um APK debug (não assinado para publicação).



**Nota:** O IP `188.165.192.24:5644` foi inserido em `server_ip.txt` e copiado para `app/src/main/assets/server_ip.txt`.


## GitHub Actions (automated release build)
This repository includes a workflow `.github/workflows/android_release_build.yml` which builds the release APK and uploads it as an artifact named `AuroraRP-release-apk`.

### Required repository secrets (set in GitHub -> Settings -> Secrets -> Actions):
- `KEYSTORE_BASE64` : your keystore file converted to base64 (see below)
- `KEYSTORE_PASSWORD` : keystore password
- `KEY_ALIAS` : alias (e.g. `aurora_key`)
- `KEY_PASSWORD` : key password

### How to create the base64 value locally (example):
```bash
base64 -w 0 aurora-release.keystore | xclip -selection clipboard
# or
base64 aurora-release.keystore > keystore.b64
```
Then paste the resulting base64 string into the `KEYSTORE_BASE64` secret.

### Run the workflow
1. Push this repository to GitHub (branch `main`).
2. Add the required secrets.
3. Go to the Actions tab, open the `Android Release Build (AuroraRP)` run and download the `AuroraRP-release-apk` artifact.
